# svgfig
Automatically exported from code.google.com/p/svgfig

This is an old project, the first in a series from Plothon (2006) to SVGFig (2008) to Plotsmanship (future).  It's a pure-Python plotting framework whose output is SVG (the C++ part is a viewer).  See the Wiki, if you're interested.
