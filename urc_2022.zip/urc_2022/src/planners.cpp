#include "urc_2022/planners.h"

using namespace traversal;

planners::planners()
{
    yaw_ = 0;
    goal_lat_ = 0;
    goal_long_ = 0;
    error_distance_ = 0;
    in_error_distance_ = 0;
    diff_angle_ = 0;
    error_angle_ = 0;
    linear_max_ = 0.25;
    linear_min_ =0.2;
    ang_max_ = 0.5;
    ang_min_ = 0.1;
    dist_thres_ = 1.5;
    ang_thres_ = 2;
}

void planners::caller()
{
    std::string goal_no;
    std::vector<double> goals;
    std::cout<<"Enter goal_no: \n";
    std::cin>>goal_no;
    std::string goal = "/goal" + goal_no;
    nh.getParam(goal, goals);

    goal_lat_ = goals[0];
    goal_long_ = goals[1];

	std::cout<<"goal_lat_: "<<goal_lat_<<" goal_long_: "<<goal_long_<<std::endl;

    ros::Rate loop_rate(1);
    // Velocity Publisher
    pub_vel_ = nh.advertise<geometry_msgs::Twist> ("/cmd_vel", 1);       
    //Callback for GPS values             
    sub_gps_ = nh.subscribe("/fix", 1000, &planners::gpsCallback, this);         
    loop_rate.sleep();
    //Callback for IMU values
    sub_imu_ = nh.subscribe("/imu", 1000, &planners::imuCallback, this);         
    //Callback for Laser Scan values
    sub_lidar_ = nh.subscribe("/laser/pcl", 1000, &planners::laserCallback, this);         
    ros::spin();
}

void planners::gpsCallback(const sensor_msgs::NavSatFix::ConstPtr& msg)
{
    sensor_lat_ = (msg->latitude);
    sensor_long_ = (msg->longitude);
	std::cout<<"sensor_lat_: "<<std::setprecision(16)<<sensor_lat_<<" sensor_long_: "<<std::setprecision(16)<<sensor_long_<<std::endl;
    in_error_distance_ = error_distance_;
    std::cout << error_distance_<<std::endl;
    distance();
}

void planners::imuCallback(const sensor_msgs::Imu::ConstPtr& msg)
{
    this->yaw_ = msg->orientation.z;
}

void planners::laserCallback(const sensor_msgs::LaserScan& msg)
{
    totalsamples = msg.ranges.size();
    required_range = 120;
    samples_taken = (totalsamples*required_range)/275;
    sectors_ = 3;
    int Iter = samples_taken/sectors_;
    int Range = 310;
    
    for(int i=0;i<sectors_;i++)
    {
        samples_.push_back(find_min_element(msg.ranges,Range,Range+Iter));
        Range += Iter;
    }
    decision();
    samples_.clear();
}

float planners::find_min_element(std::vector<float> vec,int start_index, int end_index)
{
    int size_vec = vec.size();
    float min_element = 1000;
    for(int i=start_index;i<end_index;i++)
    {
        if(vec[i]<min_element)
        {
            min_element = vec[i];
        }
    }

    return min_element;
}

void planners::distance()
{
    double diff_long = goal_long_ - sensor_long_;
	double diff_lat = goal_lat_ - sensor_lat_;
	double sensor_lat_deg = sensor_lat_ * M_PI / 180.0;
    double y = sin(diff_long) * cos(goal_lat_);
    double x = cos(sensor_lat_) * sin(goal_lat_) - sin(sensor_lat_) * cos(goal_lat_) * cos(diff_long);
    error_angle_ = atan2(y, x);
    error_angle_ = -error_angle_ * SEMI_CIRCLE / M_PI;

    typedef boost::geometry::model::point<double, 2, boost::geometry::cs::spherical_equatorial<boost::geometry::degree>> spherical_point;
    spherical_point p(sensor_long_, sensor_lat_);
    spherical_point q(goal_long_, goal_lat_);
    double dist = boost::geometry::distance(p, q);
    error_distance_ = dist*EARTH_RADIUS*1000;
    std::cout<<"distance is "<<error_distance_<<std::endl;
}

void planners::rotation()
{   
	float ang_z, vel_x;
    pid_ l,a;
    l.kp = 0.05, l.kd = 0.06;
    a.kp = 0.75, a.kd = 0;                

    if(yaw_<0)
        yaw_ = yaw_ + CIRCLE;
    if(error_angle_<0)
        error_angle_ = error_angle_ + CIRCLE;
    diff_angle_ = error_angle_ - yaw_;

    double diff_error_angle_rad; 

    if(diff_angle_ < 0)
    {
        if(abs(diff_angle_)>SEMI_CIRCLE)
        {
            diff_angle_ =  diff_angle_ + CIRCLE;
            diff_error_angle_rad = abs(diff_angle_) * M_PI /SEMI_CIRCLE;               
            ang_z = diff_error_angle_rad * a.kp; 
        }
        else
        {
            diff_error_angle_rad = abs(diff_angle_) * M_PI /SEMI_CIRCLE;               
            ang_z = - diff_error_angle_rad * a.kp;
        }

    }
    else
    {
        if(abs(diff_angle_)>SEMI_CIRCLE)
        {
            diff_angle_ =  CIRCLE - diff_angle_;
            diff_error_angle_rad = abs(diff_angle_) * M_PI /SEMI_CIRCLE;               
            ang_z = - diff_error_angle_rad * a.kp;
        }
        else
        {
            diff_error_angle_rad = abs(diff_angle_) * M_PI /SEMI_CIRCLE;               
            ang_z = diff_error_angle_rad * a.kp;                                           
        }
    }

    vel_x = error_distance_ * l.kp + l.kd*(abs(in_error_distance_ - error_distance_)) / 0.1;

    if((ang_z > ang_max_) && (ang_z > 0))
        ang_z = ang_max_;

    if((ang_z < - ang_max_) && (ang_z < 0))
        ang_z = - ang_max_;



    if(vel_x > linear_max_)
        vel_x = linear_max_;
    if(vel_x < linear_min_)
        vel_x = linear_min_;

    if(abs(diff_angle_) > ang_thres_)
    {
        this->vel_.angular.z = ang_z;
        this->vel_.linear.x = vel_x;
        this->pub_vel_.publish(vel_);
    }
    else
    {
        this->vel_.linear.x = 0;
        this->vel_.angular.z = 0;
        pub_vel_.publish(vel_);
        linearMovement();
    }

}

void planners::linearMovement()
{
	float vel_x; 
    pid_ lm;
    lm.kp = 0.05,lm.kd = 0.06;  
                                              
    vel_x = error_distance_ * lm.kp + lm.kd*(abs(in_error_distance_ - error_distance_))/0.1;

    if(vel_x > linear_max_)
        vel_x = linear_max_;
    if(vel_x < linear_min_)
        vel_x = linear_min_;

    this->vel_.linear.x = vel_x;

    pub_vel_.publish(vel_);
}

void planners::decision()
{
    if(samples_[0]>threshold && samples_[1]>threshold && samples_[2]>threshold)
    {
        std::cout<<"No Obstacle: Global Planner\n";
        if(error_distance_ > dist_thres_)
        {
            rotation();
        }   
        else
        {
            char input;
            vel_.linear.x = 0;
            vel_.angular.z = 0;
            pub_vel_.publish(vel_);
            std::cout<<"Goal Reached"<<std::endl;
            std::cout<<"Do you want to go to another goal (y or n)?"<<std::endl;
            std::cin>>input;
            if(input == 'y')
                caller();
            else
                ros::shutdown();       
        }
    }
    else if(samples_[0]>threshold && samples_[1]<threshold && samples_[2]>threshold)
    {
        std::cout<<"Obstacle: Front\n";
        vel_.linear.x = 0.0;
        vel_.angular.z = 0.3; //Left Rotation Default
        pub_vel_.publish(vel_);
    }
    else if(samples_[0]<threshold && samples_[1]>threshold && samples_[2]>threshold)
    {
        std::cout<<"Obstacle: Right\n";
        vel_.linear.x = 0.0;
        vel_.angular.z = 0.3;
        pub_vel_.publish(vel_);
    }
    else if(samples_[0]>threshold && samples_[1]>threshold && samples_[2]<threshold)
    {
        std::cout<<"Obstacle: Left\n";
        vel_.linear.x = 0.0;
        vel_.angular.z = -0.3;
        pub_vel_.publish(vel_);
    }
    else if(samples_[0]<threshold && samples_[1]<threshold && samples_[2]>threshold)
    {
        std::cout<<"Obstacle: Front & Right\n";
        vel_.linear.x = 0.0;
        vel_.angular.z = 0.3;
        pub_vel_.publish(vel_);
    }
    else if(samples_[0]>threshold && samples_[1]<threshold && samples_[2]<threshold)
    {
        std::cout<<"Obstacle: Front & Left\n";
        vel_.linear.x = 0.0;
        vel_.angular.z = -0.3;
        pub_vel_.publish(vel_);
    }
    else if(samples_[0]<threshold && samples_[1]<threshold && samples_[2]<threshold)
    {
        std::cout<<"Obstacle: Front & Right & Left\n";
        vel_.linear.x = 0.0;
        vel_.angular.z = 0.3;
        pub_vel_.publish(vel_);
    }
    else if(samples_[0]<threshold && samples_[1]>threshold && samples_[2]<threshold)
    {
        std::cout<<"Obstacle: Right & Left\n";
        vel_.linear.x = 0.0;
        vel_.angular.z = 0.3;
        pub_vel_.publish(vel_);
    }
    else 
    {
        std::cout<<"Unknown Case\n";
    }
}

