#include "urc_2022/planners.h"


int main(int argc, char** argv)
{
    ros::init(argc, argv, "URC_ALL_NODE");

    /*
     * int count = 1;
     * while (1){
     *	
     *	obstacle_avoidance()
     *
     *	switch(count){
     *	
     *	case 1: {
     *		bool reached = globalPlanner(coord[1]);
     *		// flag
     *		if(reached){
     *			bool detected = arucoDetection();
     *			if(detected)
     *				leg_traversal
     *		}
     *		count++;
     *		break;
     *		}
     *  same for 2 and 3
     *
     *  case 4: { 
     *          bool reached = globalPlanner(coord[4]);
     *          if(reached){
     *          	search_pattern();
     *                  bool detected = arucoDetection();
     *                  if(detected)
     *                          leg_traversal();
     *          }
     *
     *          break;
     *          }
     * same for 5
     *  case 6: {
     *  	bool reached = globalPlanner(coord[6]);
     *          if(reached){
     *                  search_pattern();
     *                  bool detected = arucoDetection();
     *                  if(detected)
     *                          gate_traversal();
     *          }
     *		break;
     *		}
     *	}
     *
     *	same for 7
     * }
     * */
    traversal::planners obj;
    obj.caller();
    return 0;
}


